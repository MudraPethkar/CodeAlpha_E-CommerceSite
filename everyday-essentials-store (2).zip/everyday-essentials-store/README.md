# Everyday Essentials

A complete Django storefront for considered household, clothing, electronics, personal care and stationery essentials. The app uses Django templates, SQLite and vanilla JavaScript. Checkout is a working test flow and does not process payments.

## Run in Replit

The Replit Run button starts the storefront on port 5000, applies any pending migrations, and ensures the sample catalogue is loaded. To run the same setup manually:

```bash
python manage.py migrate
python manage.py seed_products
python manage.py runserver 0.0.0.0:5000
```

The storefront is served at `/`. It uses the workspace-provided Django installation and the configured `SESSION_SECRET` for Django sessions and CSRF protection.

## Local setup

Python 3.11+ is required. Install the project dependency with `uv sync` (or `pip install -r requirements.txt`), then initialize the database and catalogue:

```bash
python manage.py migrate
python manage.py seed_products
python manage.py runserver 0.0.0.0:5000
```

The `seed_products` command is safe to run again. It adds any missing sample items without resetting existing inventory. The starter catalogue contains 25 products (five in each category). Product records can be edited in the Django admin at `/admin/`.

## Features

- Responsive home page, category links, product search and category filtering.
- Product details, stock availability and quantity-aware cart actions.
- Django registration, sign in and sign out. Guest carts are supported; signed-in users can see their order history.
- Delivery details form and payment-free test checkout.
- Delivery is $6.95 under $75 and free from $75; the server calculates and saves delivery and order totals.
- Order items retain the purchase-time name and price. Stock is checked and reduced on the server in an atomic transaction; browser-submitted totals are never used.
- Clear validation feedback, success messages and empty states.

## Database and migrations

SQLite is stored in `db.sqlite3` at the project root. After model changes, create and apply migrations:

```bash
python manage.py makemigrations shop
python manage.py migrate
```

No real card or payment information is collected.
