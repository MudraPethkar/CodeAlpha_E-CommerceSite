from .models import Cart


def cart_summary(request):
    if request.user.is_authenticated:
        cart = Cart.objects.filter(user=request.user).first()
    elif request.session.session_key:
        cart = Cart.objects.filter(session_key=request.session.session_key, user__isnull=True).first()
    else:
        cart = None
    from .models import Product

    return {
        "nav_cart_count": cart.item_count if cart else 0,
        "categories": Product.Category.choices,
    }
