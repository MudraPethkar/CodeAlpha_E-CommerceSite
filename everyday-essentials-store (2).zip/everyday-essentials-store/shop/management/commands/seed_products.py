from django.core.management.base import BaseCommand

from shop.models import Product


PRODUCTS = [
    ("home-decor", "Arc Ceramic Vase", "A softly sculpted stoneware vase with a matte sand glaze, made for fresh stems or a quiet shelf moment.", "28.00", "https://images.unsplash.com/photo-1578500494198-246f612d3b3d?auto=format&fit=crop&w=900&q=85", "Ivory ceramic vase on a neutral shelf", 18, True),
    ("home-decor", "Linen Cushion Cover", "Relaxed washed linen in a warm natural tone. A simple layer that brings softness to a sofa or bed.", "34.00", "https://images.unsplash.com/photo-1584100936595-c0654b55a2e2?auto=format&fit=crop&w=900&q=85", "Neutral linen cushion on a sofa", 24, True),
    ("home-decor", "Quiet Hour Candle", "A clean-burning soy candle with notes of cedar, fig and soft amber for slower evenings at home.", "22.00", "https://images.unsplash.com/photo-1603006905003-be475563bc59?auto=format&fit=crop&w=900&q=85", "Minimal candle in a glass vessel", 35, False),
    ("home-decor", "Woven Market Basket", "Handwoven natural-fiber basket for throws, magazines or the little things that need a home.", "46.00", "https://images.unsplash.com/photo-1593085260707-5377ba37f868?auto=format&fit=crop&w=900&q=85", "Woven natural basket beside a chair", 12, False),
    ("home-decor", "Soft Form Table Lamp", "A compact sculptural lamp with a warm glow and a gently curved ceramic base.", "78.00", "https://images.unsplash.com/photo-1507473885765-e6ed057f782c?auto=format&fit=crop&w=900&q=85", "Warm table lamp on a side table", 9, True),
    ("clothes", "Everyday Cotton Tee", "A breathable midweight cotton tee with a relaxed fit and a neckline that holds its shape.", "32.00", "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=900&q=85", "Classic white cotton t-shirt", 40, True),
    ("clothes", "Weekend Overshirt", "An easy layer in brushed cotton twill, cut roomy enough to wear over your favorite tee.", "68.00", "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?auto=format&fit=crop&w=900&q=85", "Casual overshirt in an earthy neutral", 16, True),
    ("clothes", "Ribbed Lounge Set", "Soft stretch cotton with a gentle rib texture. Comfortable at home and polished enough for a coffee run.", "74.00", "https://images.unsplash.com/photo-1551488831-00ddcb6c6bd3?auto=format&fit=crop&w=900&q=85", "Comfortable neutral lounge clothing", 14, False),
    ("clothes", "Canvas Day Tote", "A durable everyday carryall with sturdy handles and room for the things you actually bring along.", "38.00", "https://images.unsplash.com/photo-1590874103328-eac38a683ce7?auto=format&fit=crop&w=900&q=85", "Canvas tote bag hanging on a wall", 27, False),
    ("clothes", "Merino Blend Socks", "A soft, breathable merino blend with a cushioned sole for all-day comfort.", "18.00", "https://images.unsplash.com/photo-1586350977771-b3b0abd50c82?auto=format&fit=crop&w=900&q=85", "Folded neutral socks", 50, False),
    ("electronics", "Studio Wireless Headphones", "Comfortable over-ear listening with rich, balanced sound and a fold-flat design for travel.", "119.00", "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=900&q=85", "Wireless over-ear headphones", 11, True),
    ("electronics", "Pocket Bluetooth Speaker", "A compact speaker for your desk, kitchen or weekend bag, with clear sound and an easy grip.", "59.00", "https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?auto=format&fit=crop&w=900&q=85", "Small portable Bluetooth speaker", 17, True),
    ("electronics", "Desk Charging Dock", "One tidy home for your phone and earbuds, with a weighted base and soft-touch finish.", "42.00", "https://images.unsplash.com/photo-1586953208448-b95a79798f07?auto=format&fit=crop&w=900&q=85", "Minimal phone charging dock on a desk", 20, False),
    ("electronics", "Compact Film Camera", "A simple point-and-shoot film camera for snapshots that feel a little more memorable.", "89.00", "https://images.unsplash.com/photo-1516035069371-29a1b244cc32?auto=format&fit=crop&w=900&q=85", "Compact black camera on a neutral surface", 7, False),
    ("electronics", "Braided USB-C Cable", "A dependable two-meter braided cable with reinforced ends for everyday charging.", "16.00", "https://images.unsplash.com/photo-1615526675159-e248c3021d3f?auto=format&fit=crop&w=900&q=85", "Braided charging cable", 60, False),
    ("personal-care", "Daily Dew Face Serum", "A lightweight hydrating serum with a comfortable, fast-absorbing finish for morning or night.", "36.00", "https://images.unsplash.com/photo-1608248543803-ba4f8c70ae0b?auto=format&fit=crop&w=900&q=85", "Skincare serum bottle with botanical accents", 22, True),
    ("personal-care", "Gentle Hand Wash", "A plant-derived cleanser with a soft citrus and herb scent, made for the sink you use most.", "19.00", "https://images.unsplash.com/photo-1608571423902-eed4a5ad8108?auto=format&fit=crop&w=900&q=85", "Minimal hand wash bottle", 30, True),
    ("personal-care", "Calm Night Balm", "A rich, fragrance-light body balm that leaves dry skin feeling comfortable and nourished.", "28.00", "https://images.unsplash.com/photo-1601049541289-9b1b7bbbfe19?auto=format&fit=crop&w=900&q=85", "Natural skincare jar on a beige background", 15, False),
    ("personal-care", "Wooden Bath Brush", "A comfortable long-handle brush made with natural bristles for a simple, considered bath ritual.", "24.00", "https://images.unsplash.com/photo-1620916566398-39f1143ab7be?auto=format&fit=crop&w=900&q=85", "Natural bath and body care essentials", 13, False),
    ("personal-care", "Everyday Lip Care Duo", "Two cushiony balms for pockets, bedside tables and anywhere lips need a little extra care.", "14.00", "https://images.unsplash.com/photo-1586495777744-4413f21062fa?auto=format&fit=crop&w=900&q=85", "Lip balm and personal care products", 38, False),
    ("stationery", "Undated Daily Planner", "An undated planner with open daily pages, gentle prompts and room to make the day your own.", "26.00", "https://images.unsplash.com/photo-1455390582262-044cdead277a?auto=format&fit=crop&w=900&q=85", "Notebook and pen on a clean desk", 33, True),
    ("stationery", "Softcover Notes Journal", "A lay-flat journal with smooth, fountain-pen-friendly pages and a flexible linen-texture cover.", "21.00", "https://images.unsplash.com/photo-1517842645767-c639042777db?auto=format&fit=crop&w=900&q=85", "Open notebook with handwritten notes", 29, True),
    ("stationery", "Color Study Pencil Set", "Six artist-grade graphite pencils in a reusable paper sleeve, from soft sketch to fine detail.", "17.00", "https://images.unsplash.com/photo-1513364776144-60967b0f800f?auto=format&fit=crop&w=900&q=85", "Drawing pencils and art supplies", 45, False),
    ("stationery", "Brass Page Clips", "A set of four slim brass clips to keep a book open, mark a page or hold a small stack together.", "12.00", "https://images.unsplash.com/photo-1456324504439-367cee3b3c32?auto=format&fit=crop&w=900&q=85", "Paper clips and stationery on a desk", 55, False),
    ("stationery", "Everyday Gel Pen Set", "Three smooth-writing gel pens with fine tips and archival black ink for lists and letters.", "15.00", "https://images.unsplash.com/photo-1583485088034-697b5bc54ccd?auto=format&fit=crop&w=900&q=85", "Pens arranged on a paper notebook", 42, False),
]


class Command(BaseCommand):
    help = "Load the Everyday Essentials sample catalogue (25 products)."

    def handle(self, *args, **options):
        created = 0
        updated = 0
        for category, name, description, price, image_url, image_alt, stock, featured in PRODUCTS:
            _, was_created = Product.objects.get_or_create(
                name=name,
                defaults={
                    "category": category,
                    "description": description,
                    "price": price,
                    "image_url": image_url,
                    "image_alt": image_alt,
                    "stock_quantity": stock,
                    "is_featured": featured,
                },
            )
            created += int(was_created)
            updated += int(not was_created)
        self.stdout.write(self.style.SUCCESS(f"Catalogue ready: {created} created, {updated} updated."))
