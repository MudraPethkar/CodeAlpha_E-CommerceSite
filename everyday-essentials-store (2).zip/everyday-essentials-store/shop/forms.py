from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User


class RegisterForm(UserCreationForm):
    email = forms.EmailField()
    first_name = forms.CharField(max_length=80, required=True, label="Name")

    class Meta:
        model = User
        fields = ["first_name", "username", "email", "password1", "password2"]


class CheckoutForm(forms.Form):
    recipient_name = forms.CharField(max_length=160, label="Full name")
    email = forms.EmailField()
    phone = forms.CharField(max_length=40)
    address = forms.CharField(max_length=240, label="Street address")
    city = forms.CharField(max_length=100)
    postal_code = forms.CharField(max_length=20, label="Postal code")
