from decimal import Decimal

from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.db import transaction
from django.db.models import F, Q
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from .forms import CheckoutForm, RegisterForm
from .models import Cart, CartItem, Order, OrderItem, Product

FREE_DELIVERY_THRESHOLD = Decimal("75.00")
STANDARD_DELIVERY = Decimal("6.95")


def get_cart(request):
    if request.user.is_authenticated:
        cart, _ = Cart.objects.get_or_create(user=request.user)
        return cart
    if not request.session.session_key:
        request.session.create()
    cart, _ = Cart.objects.get_or_create(session_key=request.session.session_key, user__isnull=True)
    return cart


def home(request):
    featured = Product.objects.filter(is_featured=True, stock_quantity__gt=0)[:8]
    if not featured:
        featured = Product.objects.filter(stock_quantity__gt=0)[:8]
    return render(
        request,
        "shop/home.html",
        {"featured_products": featured, "categories": Product.Category.choices},
    )


def product_list(request):
    products = Product.objects.all()
    category = request.GET.get("category", "").strip()
    query = request.GET.get("q", "").strip()
    if category in Product.Category.values:
        products = products.filter(category=category)
    else:
        category = ""
    if query:
        products = products.filter(Q(name__icontains=query) | Q(description__icontains=query))
    return render(
        request,
        "shop/product_list.html",
        {
            "products": products,
            "categories": Product.Category.choices,
            "selected_category": category,
            "selected_category_name": Product.Category(category).label if category else "",
            "search_query": query,
        },
    )


def product_detail(request, slug):
    product = get_object_or_404(Product, slug=slug)
    related_products = Product.objects.filter(category=product.category).exclude(pk=product.pk)[:4]
    return render(
        request,
        "shop/product_detail.html",
        {"product": product, "related_products": related_products},
    )


def cart_view(request):
    cart = get_cart(request)
    items = cart.items.select_related("product").all()
    shipping_cost = Decimal("0.00") if cart.total >= FREE_DELIVERY_THRESHOLD else STANDARD_DELIVERY
    return render(
        request,
        "shop/cart.html",
        {
            "cart": cart,
            "items": items,
            "shipping_cost": shipping_cost,
            "grand_total": cart.total + shipping_cost,
        },
    )


@require_POST
def add_to_cart(request, slug):
    product = get_object_or_404(Product, slug=slug)
    try:
        quantity = int(request.POST.get("quantity", "1"))
    except (TypeError, ValueError):
        quantity = 0
    if quantity < 1:
        messages.error(request, "Choose a quantity of at least one.")
    elif quantity > product.stock_quantity:
        messages.error(request, f"Only {product.stock_quantity} are currently available.")
    else:
        cart = get_cart(request)
        item, created = CartItem.objects.get_or_create(cart=cart, product=product, defaults={"quantity": quantity})
        if not created:
            new_quantity = item.quantity + quantity
            if new_quantity > product.stock_quantity:
                messages.error(request, f"Your cart can contain up to {product.stock_quantity} of this item.")
            else:
                item.quantity = new_quantity
                item.save(update_fields=["quantity"])
                messages.success(request, f"{product.name} added to your bag.")
        else:
            messages.success(request, f"{product.name} added to your bag.")
    return redirect("cart")


@require_POST
def update_cart_item(request, item_id):
    cart = get_cart(request)
    item = get_object_or_404(CartItem.objects.select_related("product"), pk=item_id, cart=cart)
    try:
        quantity = int(request.POST.get("quantity", "0"))
    except (TypeError, ValueError):
        quantity = 0
    if quantity < 1:
        item.delete()
        messages.success(request, "Item removed from your bag.")
    elif quantity > item.product.stock_quantity:
        messages.error(request, f"Only {item.product.stock_quantity} are currently available.")
    else:
        item.quantity = quantity
        item.save(update_fields=["quantity"])
        messages.success(request, "Your bag has been updated.")
    return redirect("cart")


@require_POST
def remove_cart_item(request, item_id):
    cart = get_cart(request)
    item = get_object_or_404(CartItem, pk=item_id, cart=cart)
    item.delete()
    messages.success(request, "Item removed from your bag.")
    return redirect("cart")


def checkout(request):
    cart = get_cart(request)
    items = list(cart.items.select_related("product").all())
    if not items:
        messages.info(request, "Your bag is empty. Add something lovely before checkout.")
        return redirect("product_list")

    initial = {}
    if request.user.is_authenticated:
        initial = {
            "recipient_name": request.user.get_full_name() or request.user.username,
            "email": request.user.email,
        }
    form = CheckoutForm(request.POST or None, initial=initial)
    if request.method == "POST" and form.is_valid():
        try:
            with transaction.atomic():
                locked_items = list(
                    cart.items.select_related("product").select_for_update().order_by("product_id")
                )
                if not locked_items:
                    messages.error(request, "Your bag is empty.")
                    return redirect("cart")
                for item in locked_items:
                    product = Product.objects.select_for_update().get(pk=item.product_id)
                    if item.quantity > product.stock_quantity:
                        raise ValueError(f"{product.name} has only {product.stock_quantity} left.")
                subtotal = sum((item.product.price * item.quantity for item in locked_items), Decimal("0.00"))
                shipping_cost = Decimal("0.00") if subtotal >= FREE_DELIVERY_THRESHOLD else STANDARD_DELIVERY
                order = Order.objects.create(
                    user=request.user if request.user.is_authenticated else None,
                    shipping_cost=shipping_cost,
                    total=subtotal + shipping_cost,
                    **form.cleaned_data,
                )
                for item in locked_items:
                    updated = Product.objects.filter(
                        pk=item.product_id, stock_quantity__gte=item.quantity
                    ).update(stock_quantity=F("stock_quantity") - item.quantity)
                    if not updated:
                        raise ValueError(f"{item.product.name} just sold out. Update your bag to continue.")
                    OrderItem.objects.create(
                        order=order,
                        product=item.product,
                        product_name=item.product.name,
                        unit_price=item.product.price,
                        quantity=item.quantity,
                    )
                cart.items.all().delete()
        except ValueError as error:
            form.add_error(None, str(error))
        else:
            messages.success(request, "Your order is confirmed. Thank you for shopping with us.")
            return redirect("order_confirmation", order_number=order.order_number)
    shipping_cost = Decimal("0.00") if cart.total >= FREE_DELIVERY_THRESHOLD else STANDARD_DELIVERY
    return render(
        request,
        "shop/checkout.html",
        {
            "form": form,
            "cart": cart,
            "items": items,
            "shipping_cost": shipping_cost,
            "grand_total": cart.total + shipping_cost,
        },
    )


def order_confirmation(request, order_number):
    order = get_object_or_404(Order.objects.prefetch_related("items"), order_number=order_number)
    if order.user_id and (not request.user.is_authenticated or request.user.pk != order.user_id):
        messages.error(request, "That order is not available for this account.")
        return redirect("home")
    return render(request, "shop/order_confirmation.html", {"order": order})


@login_required
def order_history(request):
    orders = Order.objects.filter(user=request.user).prefetch_related("items")
    return render(request, "shop/order_history.html", {"orders": orders})


def register(request):
    if request.user.is_authenticated:
        return redirect("home")
    form = RegisterForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        user = form.save()
        login(request, user)
        messages.success(request, "Your account is ready. Welcome to Everyday.")
        return redirect("home")
    return render(request, "shop/register.html", {"form": form})
