import os
import sys

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "storefront.settings")

from django.core.management import execute_from_command_line

if __name__ == "__main__":
    if len(sys.argv) == 1:
        from django.core.management import call_command

        call_command("migrate", interactive=False)
        call_command("seed_products")
        sys.argv.extend(["runserver", "0.0.0.0:5000"])
    execute_from_command_line(sys.argv)
