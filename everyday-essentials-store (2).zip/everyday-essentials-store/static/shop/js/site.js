document.addEventListener("DOMContentLoaded", () => {
  const toggle = document.querySelector("[data-menu-toggle]");
  const mobileMenu = document.querySelector("[data-mobile-menu]");
  if (toggle && mobileMenu) {
    toggle.addEventListener("click", () => {
      const isOpen = toggle.getAttribute("aria-expanded") === "true";
      toggle.setAttribute("aria-expanded", String(!isOpen));
      mobileMenu.classList.toggle("is-open", !isOpen);
    });
  }

  document.querySelectorAll("[data-quantity-step]").forEach((button) => {
    button.addEventListener("click", () => {
      const input = button.parentElement?.querySelector("input");
      if (!input) return;
      const min = Number(input.min || 1);
      const max = Number(input.max || Number.MAX_SAFE_INTEGER);
      const direction = Number(button.dataset.quantityStep);
      input.value = String(Math.min(max, Math.max(min, Number(input.value || min) + direction)));
      input.dispatchEvent(new Event("change", { bubbles: true }));
    });
  });

  document.querySelectorAll(".notice-close").forEach((button) => {
    button.addEventListener("click", () => button.closest(".notice")?.remove());
  });
});
